#ifndef SERVER_H
#define SERVER_H

#include <string>
#include <map>
#include <functional>
#include <thread>
#include <mutex>
#include <memory>

class BlogManager;

class HttpServer {
public:
    HttpServer(int port);
    ~HttpServer();
    
    void start();
    void stop();
    
    void setBlogManager(BlogManager* manager);
    
private:
    int port_;
    int server_fd_;
    bool running_;
    std::thread server_thread_;
    BlogManager* blog_manager_;
    std::mutex mutex_;
    
    void handleClient(int client_socket);
    std::string handleRequest(const std::string& method, const std::string& path, 
                             const std::string& body);
    std::string getContentType(const std::string& path);
    std::string readFile(const std::string& path);
    
    // 路由处理函数
    std::string handleIndex();
    std::string handlePost(int post_id);
    std::string handleAbout();
    std::string handleAdmin();
    std::string handleApiPosts(const std::string& method, const std::string& body);
    std::string handleApiPost(int post_id, const std::string& method, const std::string& body);
    
    // 静态文件服务
    std::string serveStaticFile(const std::string& path);
};

#endif