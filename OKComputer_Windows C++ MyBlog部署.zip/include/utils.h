#ifndef UTILS_H
#define UTILS_H

#include <string>
#include <vector>

namespace Utils {
    // 字符串工具函数
    std::string trim(const std::string& str);
    std::vector<std::string> split(const std::string& str, char delimiter);
    std::string join(const std::vector<std::string>& vec, const std::string& delimiter);
    
    // HTML转义
    std::string escapeHtml(const std::string& str);
    
    // 时间格式化
    std::string formatDate(const std::string& timestamp);
    
    // 文件操作
    bool fileExists(const std::string& path);
    std::string readFile(const std::string& path);
    bool writeFile(const std::string& path, const std::string& content);
}

#endif