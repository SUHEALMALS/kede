#ifndef BLOG_MANAGER_H
#define BLOG_MANAGER_H

#include <string>
#include <vector>
#include <map>
#include <memory>
#include <mutex>

struct BlogPost {
    int id;
    std::string title;
    std::string content;
    std::string author;
    std::string created_at;
    std::string updated_at;
    std::vector<std::string> tags;
    bool published;
    
    BlogPost() : id(0), published(true) {}
    
    // 转换为JSON字符串
    std::string toJson() const;
    
    // 从JSON字符串解析
    static BlogPost fromJson(const std::string& json_str);
};

class BlogManager {
public:
    explicit BlogManager(const std::string& data_file);
    ~BlogManager();
    
    // 文章管理接口
    std::vector<BlogPost> getAllPosts();
    BlogPost getPost(int id);
    int createPost(const BlogPost& post);
    bool updatePost(int id, const BlogPost& post);
    bool deletePost(int id);
    
    // 搜索和过滤
    std::vector<BlogPost> searchPosts(const std::string& keyword);
    std::vector<BlogPost> getPostsByTag(const std::string& tag);
    
    // 数据持久化
    bool loadFromFile();
    bool saveToFile();
    
private:
    std::string data_file_;
    std::vector<BlogPost> posts_;
    std::mutex mutex_;
    int next_id_;
    
    // 工具函数
    std::string generateTimestamp();
    int findPostIndex(int id);
};

#endif