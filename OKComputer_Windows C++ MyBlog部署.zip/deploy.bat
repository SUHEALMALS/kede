@echo off
REM Windows部署脚本 for MyBlog C++ Blog System

echo ====================================
echo MyBlog C++ Blog System 部署脚本
echo ====================================

REM 检查是否以管理员权限运行
net session >nul 2>&1
if %errorLevel% neq 0 (
    echo 错误：需要以管理员权限运行此脚本
    echo 请右键点击脚本选择"以管理员身份运行"
    pause
    exit /b 1
)

REM 设置变量
set PROJECT_NAME=MyBlog
set BUILD_DIR=build
set INSTALL_DIR=C:\MyBlog
set PORT=8080

REM 创建构建目录
echo 正在创建构建目录...
if not exist %BUILD_DIR% mkdir %BUILD_DIR%
cd %BUILD_DIR%

REM 运行CMake
echo 正在配置项目...
cmake -G "Visual Studio 17 2022" -A x64 .. -DCMAKE_INSTALL_PREFIX=%INSTALL_DIR%
if errorlevel 1 (
    echo CMake配置失败
    pause
    exit /b 1
)

REM 构建项目
echo 正在构建项目...
cmake --build . --config Release
if errorlevel 1 (
    echo 构建失败
    pause
    exit /b 1
)

REM 安装项目
echo 正在安装项目...
cmake --install . --config Release
if errorlevel 1 (
    echo 安装失败
    pause
    exit /b 1
)

REM 创建服务脚本
echo 正在创建服务脚本...
cd %INSTALL_DIR%

REM 创建启动脚本
echo @echo off > start.bat
echo cd /d "%~dp0" >> start.bat
echo echo 正在启动MyBlog服务器... >> start.bat
echo MyBlog.exe >> start.bat
echo echo 服务器已启动，请访问 http://localhost:%PORT% >> start.bat
echo pause >> start.bat

REM 创建停止脚本
echo @echo off > stop.bat
echo taskkill /f /im MyBlog.exe 2^>nul >> stop.bat
echo echo 服务器已停止 >> stop.bat

REM 创建重启脚本
echo @echo off > restart.bat
echo call stop.bat >> restart.bat
echo timeout /t 2 ^>nul >> restart.bat
echo call start.bat >> restart.bat

REM 复制初始数据文件
echo 正在准备初始数据...
if not exist data mkdir data
if not exist data\posts.json (
    echo [ > data\posts.json
    echo ] >> data\posts.json
)

REM 设置防火墙规则
echo 正在配置防火墙规则...
netsh advfirewall firewall add rule name="MyBlog Server" dir=in action=allow protocol=TCP localport=%PORT% >nul 2>&1

REM 创建桌面快捷方式
echo 正在创建桌面快捷方式...
set DESKTOP=%USERPROFILE%\Desktop
set SCRIPT=%TEMP%\create_shortcut.vbs

echo Set oWS = WScript.CreateObject("WScript.Shell") > %SCRIPT%
echo sLinkFile = "%DESKTOP%\MyBlog.lnk" >> %SCRIPT%
echo Set oLink = oWS.CreateShortcut(sLinkFile) >> %SCRIPT%
echo oLink.TargetPath = "%INSTALL_DIR%\start.bat" >> %SCRIPT%
echo oLink.WorkingDirectory = "%INSTALL_DIR%" >> %SCRIPT%
echo oLink.Description = "MyBlog C++ Blog System" >> %SCRIPT%
echo oLink.IconLocation = "%SYSTEMROOT%\System32\shell32.dll,21" >> %SCRIPT%
echo oLink.Save >> %SCRIPT%

cscript //nologo %SCRIPT%
del %SCRIPT%

echo ====================================
echo 部署完成！
echo ====================================
echo 安装目录：%INSTALL_DIR%
echo 配置文件：%INSTALL_DIR%\data\posts.json
echo 启动脚本：%INSTALL_DIR%\start.bat
echo 访问地址：http://localhost:%PORT%
echo 桌面快捷方式已创建

echo.
echo 使用方法：
echo 1. 双击桌面上的"MyBlog"快捷方式
echo 2. 或在安装目录中运行 start.bat
echo 3. 打开浏览器访问 http://localhost:%PORT%
echo.
echo 管理后台：http://localhost:%PORT%/admin

echo.
pause