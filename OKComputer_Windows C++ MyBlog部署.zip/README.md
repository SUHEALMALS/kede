# MyBlog - C++ 高性能博客系统

一个使用现代C++技术栈构建的高性能博客系统，具有轻量级、高性能、易部署的特点。

## 🌟 特性

- **高性能**: 使用C++原生实现，性能优异
- **轻量级**: 单文件可执行程序，零依赖部署
- **现代化**: 支持RESTful API，响应式前端设计
- **易部署**: 一键部署脚本，Windows原生支持
- **功能完整**: 包含文章管理、用户界面、管理后台

## 🚀 快速开始

### Windows 部署

1. **下载项目**
   ```bash
   git clone https://github.com/yourusername/myblog.git
   cd myblog
   ```

2. **运行部署脚本**
   ```bash
   # 以管理员身份运行
   deploy.bat
   ```

3. **访问博客**
   - 主页: http://localhost:8080
   - 管理后台: http://localhost:8080/admin

### 手动构建

1. **安装依赖**
   - CMake 3.10+
   - C++17 编译器 (Visual Studio 2019+ / GCC 7+ / Clang 6+)

2. **构建项目**
   ```bash
   mkdir build
   cd build
   cmake ..
   cmake --build . --config Release
   ```

3. **运行服务器**
   ```bash
   ./MyBlog
   ```

## 📁 项目结构

```
MyBlog/
├── src/                    # C++源代码
│   ├── main.cpp           # 主程序入口
│   ├── server.cpp         # HTTP服务器实现
│   ├── blog_manager.cpp   # 博客管理逻辑
│   └── utils.cpp          # 工具函数
├── include/               # 头文件
├── static/                # 静态资源
│   ├── css/               # 样式文件
│   ├── js/                # JavaScript文件
│   └── images/            # 图片资源
├── templates/             # HTML模板
├── data/                  # 数据文件
├── CMakeLists.txt         # CMake构建文件
├── deploy.bat            # Windows部署脚本
└── README.md             # 项目说明
```

## 🛠️ 技术栈

### 后端
- **C++17**: 现代C++标准
- **原生Socket**: 轻量级HTTP服务器
- **JSON**: 数据存储格式
- **多线程**: 并发请求处理

### 前端
- **HTML5/CSS3**: 现代化界面
- **JavaScript ES6+**: 交互逻辑
- **响应式设计**: 适配各种设备
- **CSS Grid/Flexbox**: 布局系统

## 📋 功能说明

### 用户功能
- ✅ 文章列表浏览
- ✅ 文章详情查看
- ✅ 标签分类
- ✅ 文章搜索
- ✅ 关于页面
- ✅ 响应式设计

### 管理功能
- ✅ 文章创建/编辑
- ✅ 文章删除
- ✅ 草稿管理
- ✅ 系统统计
- ✅ 管理后台

### API接口
- `GET /api/posts` - 获取文章列表
- `GET /api/posts/:id` - 获取单篇文章
- `POST /api/posts` - 创建新文章
- `PUT /api/posts/:id` - 更新文章
- `DELETE /api/posts/:id` - 删除文章

## ⚙️ 配置说明

### 服务器配置
服务器使用默认配置：
- 端口: 8080
- 主机: 0.0.0.0 (所有网络接口)
- 数据文件: data/posts.json

### 修改配置
可以通过修改源码中的配置参数来定制：
```cpp
// 在 main.cpp 中修改
HttpServer server(8080);  // 修改端口号
```

## 🔧 开发指南

### 添加新功能
1. 在 `include/` 目录添加头文件
2. 在 `src/` 目录实现功能
3. 在 `server.cpp` 中添加路由处理
4. 更新前端模板和脚本

### 数据库扩展
当前使用JSON文件存储，可以扩展支持：
- SQLite
- MySQL
- PostgreSQL
- MongoDB

### 前端定制
- 修改 `static/css/style.css` 调整样式
- 修改 `static/js/main.js` 添加交互功能
- 修改 `templates/` 目录下的HTML模板

## 🌐 部署选项

### Windows 服务
可以将博客系统注册为Windows服务：
```bash
sc create MyBlog binPath= "C:\MyBlog\MyBlog.exe"
sc start MyBlog
```

### Linux 服务
创建systemd服务文件：
```ini
[Unit]
Description=MyBlog C++ Blog System
After=network.target

[Service]
Type=simple
User=www-data
WorkingDirectory=/opt/myblog
ExecStart=/opt/myblog/MyBlog
Restart=always

[Install]
WantedBy=multi-user.target
```

### Docker 容器
创建Dockerfile：
```dockerfile
FROM ubuntu:20.04
COPY MyBlog /usr/local/bin/
COPY static /usr/local/bin/static
COPY templates /usr/local/bin/templates
COPY data /usr/local/bin/data
EXPOSE 8080
CMD ["MyBlog"]
```

## 📈 性能优化

### 编译优化
```bash
cmake -DCMAKE_BUILD_TYPE=Release ..
cmake --build . --config Release
```

### 运行优化
- 启用编译器优化选项
- 使用连接池减少系统开销
- 实现缓存机制
- 启用压缩传输

## 🔒 安全考虑

- 输入验证和过滤
- XSS防护
- CSRF防护
- 访问控制
- 数据备份

## 📄 许可证

MIT License - 详见 LICENSE 文件

## 🤝 贡献

欢迎提交Issue和Pull Request来改进项目！

## 📞 联系方式

- Email: developer@example.com
- GitHub: github.com/developer
- 项目地址: https://github.com/yourusername/myblog

## 🙏 致谢

感谢所有为这个项目做出贡献的开发者们！

---

**享受使用 MyBlog C++ 博客系统！** 🚀