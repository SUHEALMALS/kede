# C++博客系统项目大纲

## 项目结构
```
/mnt/okcomputer/output/
├── src/                    # C++源代码
│   ├── main.cpp           # 主程序入口
│   ├── server.cpp         # HTTP服务器实现
│   ├── blog_manager.cpp   # 博客管理逻辑
│   └── utils.cpp          # 工具函数
├── include/               # 头文件
│   ├── server.h
│   ├── blog_manager.h
│   └── utils.h
├── static/                # 静态资源
│   ├── css/
│   │   └── style.css      # 主样式文件
│   ├── js/
│   │   └── main.js        # 前端交互脚本
│   └── images/            # 图片资源
├── templates/             # HTML模板
│   ├── index.html         # 首页模板
│   ├── post.html          # 文章页模板
│   ├── about.html         # 关于页模板
│   └── admin.html         # 管理后台模板
├── data/                  # 数据文件
│   ├── posts.json         # 文章数据
│   └── config.json        # 配置文件
├── CMakeLists.txt         # CMake构建文件
├── README.md              # 项目说明
└── deploy.bat            # Windows部署脚本
```

## 核心功能模块

### 1. HTTP服务器模块 (server.h/cpp)
- 处理HTTP请求和响应
- 路由分发和静态文件服务
- JSON API接口实现

### 2. 博客管理模块 (blog_manager.h/cpp)
- 文章的增删改查操作
- 数据持久化到JSON文件
- 搜索和分类功能

### 3. 工具模块 (utils.h/cpp)
- JSON解析和生成
- 时间处理和格式化
- 字符串处理函数

### 4. 前端界面
- 响应式HTML模板
- 现代化CSS样式
- JavaScript交互逻辑

## 部署特性
- 单文件可执行程序
- 内置HTTP服务器
- 零依赖部署（静态链接）
- Windows原生支持