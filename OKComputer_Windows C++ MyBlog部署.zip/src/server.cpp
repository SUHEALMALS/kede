#include "../include/server.h"
#include "../include/blog_manager.h"
#include <iostream>
#include <sstream>
#include <fstream>
#include <filesystem>
#include <regex>
#include <chrono>
#include <ctime>

#ifdef _WIN32
#include <winsock2.h>
#include <ws2tcpip.h>
#pragma comment(lib, "ws2_32.lib")
#define CLOSE_SOCKET closesocket
#define SOCKET_ERROR_VALUE SOCKET_ERROR
#else
#include <sys/socket.h>
#include <netinet/in.h>
#include <unistd.h>
#include <arpa/inet.h>
#define CLOSE_SOCKET close
#define SOCKET_ERROR_VALUE -1
#endif

namespace fs = std::filesystem;

HttpServer::HttpServer(int port) : port_(port), server_fd_(-1), 
                                   running_(false), blog_manager_(nullptr) {
#ifdef _WIN32
    WSADATA wsaData;
    WSAStartup(MAKEWORD(2, 2), &wsaData);
#endif
}

HttpServer::~HttpServer() {
    stop();
#ifdef _WIN32
    WSACleanup();
#endif
}

void HttpServer::setBlogManager(BlogManager* manager) {
    blog_manager_ = manager;
}

void HttpServer::start() {
    server_fd_ = socket(AF_INET, SOCK_STREAM, 0);
    if (server_fd_ == -1) {
        std::cerr << "Failed to create socket" << std::endl;
        return;
    }

    // 设置socket选项
    int opt = 1;
    setsockopt(server_fd_, SOL_SOCKET, SO_REUSEADDR, (char*)&opt, sizeof(opt));

    sockaddr_in address;
    address.sin_family = AF_INET;
    address.sin_addr.s_addr = INADDR_ANY;
    address.sin_port = htons(port_);

    if (bind(server_fd_, (sockaddr*)&address, sizeof(address)) < 0) {
        std::cerr << "Bind failed" << std::endl;
        CLOSE_SOCKET(server_fd_);
        return;
    }

    if (listen(server_fd_, 10) < 0) {
        std::cerr << "Listen failed" << std::endl;
        CLOSE_SOCKET(server_fd_);
        return;
    }

    running_ = true;
    
    while (running_) {
        sockaddr_in client_address;
        int addrlen = sizeof(client_address);
        int client_socket = accept(server_fd_, (sockaddr*)&client_address, &addrlen);
        
        if (client_socket < 0) {
            continue;
        }

        std::thread client_thread(&HttpServer::handleClient, this, client_socket);
        client_thread.detach();
    }
}

void HttpServer::stop() {
    running_ = false;
    if (server_fd_ != -1) {
        CLOSE_SOCKET(server_fd_);
        server_fd_ = -1;
    }
}

void HttpServer::handleClient(int client_socket) {
    char buffer[4096];
    int bytes_read = recv(client_socket, buffer, sizeof(buffer) - 1, 0);
    
    if (bytes_read > 0) {
        buffer[bytes_read] = '\0';
        std::string request(buffer);
        
        // 解析HTTP请求
        std::istringstream request_stream(request);
        std::string method, path, version;
        request_stream >> method >> path >> version;
        
        // 获取请求体
        std::string body;
        size_t body_start = request.find("\r\n\r\n");
        if (body_start != std::string::npos) {
            body = request.substr(body_start + 4);
        }
        
        // 处理请求
        std::string response = handleRequest(method, path, body);
        
        // 发送响应
        send(client_socket, response.c_str(), response.length(), 0);
    }
    
    CLOSE_SOCKET(client_socket);
}

std::string HttpServer::handleRequest(const std::string& method, const std::string& path, 
                                    const std::string& body) {
    std::string response;
    
    // 静态文件服务
    if (path.find("/static/") == 0) {
        return serveStaticFile(path.substr(8));
    }
    
    // API路由
    if (path.find("/api/posts") == 0) {
        if (path == "/api/posts") {
            return handleApiPosts(method, body);
        } else {
            // 提取文章ID
            std::regex post_regex("/api/posts/(\\d+)");
            std::smatch match;
            if (std::regex_match(path, match, post_regex)) {
                int post_id = std::stoi(match[1]);
                return handleApiPost(post_id, method, body);
            }
        }
    }
    
    // 页面路由
    if (path == "/" || path == "/index.html") {
        response = handleIndex();
    } else if (path.find("/post/") == 0) {
        std::regex post_regex("/post/(\\d+)");
        std::smatch match;
        if (std::regex_match(path, match, post_regex)) {
            int post_id = std::stoi(match[1]);
            response = handlePost(post_id);
        } else {
            response = "HTTP/1.1 404 Not Found\r\n\r\n404 Not Found";
        }
    } else if (path == "/about") {
        response = handleAbout();
    } else if (path == "/admin") {
        response = handleAdmin();
    } else {
        response = "HTTP/1.1 404 Not Found\r\n\r\n404 Not Found";
    }
    
    return response;
}

std::string HttpServer::getContentType(const std::string& path) {
    if (path.find(".css") != std::string::npos) return "text/css";
    if (path.find(".js") != std::string::npos) return "application/javascript";
    if (path.find(".png") != std::string::npos) return "image/png";
    if (path.find(".jpg") != std::string::npos || path.find(".jpeg") != std::string::npos) return "image/jpeg";
    if (path.find(".gif") != std::string::npos) return "image/gif";
    if (path.find(".svg") != std::string::npos) return "image/svg+xml";
    return "text/html";
}

std::string HttpServer::readFile(const std::string& path) {
    std::ifstream file("static/" + path);
    if (!file.is_open()) {
        return "";
    }
    
    std::stringstream buffer;
    buffer << file.rdbuf();
    return buffer.str();
}

std::string HttpServer::serveStaticFile(const std::string& path) {
    std::string content = readFile(path);
    if (content.empty()) {
        return "HTTP/1.1 404 Not Found\r\n\r\n404 Not Found";
    }
    
    std::string content_type = getContentType(path);
    std::ostringstream response;
    response << "HTTP/1.1 200 OK\r\n";
    response << "Content-Type: " << content_type << "\r\n";
    response << "Content-Length: " << content.length() << "\r\n";
    response << "\r\n";
    response << content;
    
    return response.str();
}

std::string HttpServer::handleIndex() {
    std::string template_content = readFile("../templates/index.html");
    if (template_content.empty()) {
        return "HTTP/1.1 500 Internal Server Error\r\n\r\nTemplate not found";
    }
    
    // 这里可以添加动态内容替换逻辑
    
    std::ostringstream response;
    response << "HTTP/1.1 200 OK\r\n";
    response << "Content-Type: text/html\r\n";
    response << "Content-Length: " << template_content.length() << "\r\n";
    response << "\r\n";
    response << template_content;
    
    return response.str();
}

std::string HttpServer::handlePost(int post_id) {
    std::string template_content = readFile("../templates/post.html");
    if (template_content.empty()) {
        return "HTTP/1.1 500 Internal Server Error\r\n\r\nTemplate not found";
    }
    
    std::ostringstream response;
    response << "HTTP/1.1 200 OK\r\n";
    response << "Content-Type: text/html\r\n";
    response << "Content-Length: " << template_content.length() << "\r\n";
    response << "\r\n";
    response << template_content;
    
    return response.str();
}

std::string HttpServer::handleAbout() {
    std::string template_content = readFile("../templates/about.html");
    if (template_content.empty()) {
        return "HTTP/1.1 500 Internal Server Error\r\n\r\nTemplate not found";
    }
    
    std::ostringstream response;
    response << "HTTP/1.1 200 OK\r\n";
    response << "Content-Type: text/html\r\n";
    response << "Content-Length: " << template_content.length() << "\r\n";
    response << "\r\n";
    response << template_content;
    
    return response.str();
}

std::string HttpServer::handleAdmin() {
    std::string template_content = readFile("../templates/admin.html");
    if (template_content.empty()) {
        return "HTTP/1.1 500 Internal Server Error\r\n\r\nTemplate not found";
    }
    
    std::ostringstream response;
    response << "HTTP/1.1 200 OK\r\n";
    response << "Content-Type: text/html\r\n";
    response << "Content-Length: " << template_content.length() << "\r\n";
    response << "\r\n";
    response << template_content;
    
    return response.str();
}

std::string HttpServer::handleApiPosts(const std::string& method, const std::string& body) {
    if (method == "GET") {
        // 返回所有文章列表
        return "HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n{\"posts\":[]}";
    } else if (method == "POST") {
        // 创建新文章
        return "HTTP/1.1 201 Created\r\nContent-Type: application/json\r\n\r\n{\"id\":1,\"status\":\"created\"}";
    }
    
    return "HTTP/1.1 405 Method Not Allowed\r\n\r\nMethod Not Allowed";
}

std::string HttpServer::handleApiPost(int post_id, const std::string& method, const std::string& body) {
    if (method == "GET") {
        // 返回单篇文章
        return "HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n{\"id\":" + std::to_string(post_id) + "}";
    } else if (method == "PUT") {
        // 更新文章
        return "HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n{\"id\":" + std::to_string(post_id) + ",\"status\":\"updated\"}";
    } else if (method == "DELETE") {
        // 删除文章
        return "HTTP/1.1 204 No Content\r\n\r\n";
    }
    
    return "HTTP/1.1 405 Method Not Allowed\r\n\r\nMethod Not Allowed";
}