#include "../include/blog_manager.h"
#include <fstream>
#include <sstream>
#include <iomanip>
#include <ctime>
#include <algorithm>
#include <cctype>

// BlogPost实现
std::string BlogPost::toJson() const {
    std::ostringstream json;
    json << "{\n";
    json << "  \"id\": " << id << ",\n";
    json << "  \"title\": \"" << title << "\",\n";
    json << "  \"content\": \"" << content << "\",\n";
    json << "  \"author\": \"" << author << "\",\n";
    json << "  \"created_at\": \"" << created_at << "\",\n";
    json << "  \"updated_at\": \"" << updated_at << "\",\n";
    json << "  \"tags\": [";
    
    for (size_t i = 0; i < tags.size(); ++i) {
        if (i > 0) json << ", ";
        json << "\"" << tags[i] << "\"";
    }
    json << "],\n";
    json << "  \"published\": " << (published ? "true" : "false") << "\n";
    json << "}";
    return json.str();
}

BlogPost BlogPost::fromJson(const std::string& json_str) {
    BlogPost post;
    // 简化的JSON解析，实际项目中应使用专门的JSON库
    std::string str = json_str;
    
    // 提取ID
    size_t id_pos = str.find("\"id\":");
    if (id_pos != std::string::npos) {
        id_pos += 6;
        size_t comma_pos = str.find(",", id_pos);
        post.id = std::stoi(str.substr(id_pos, comma_pos - id_pos));
    }
    
    // 提取标题
    size_t title_pos = str.find("\"title\":");
    if (title_pos != std::string::npos) {
        title_pos += 10;
        size_t quote_end = str.find("\"", title_pos);
        post.title = str.substr(title_pos, quote_end - title_pos);
    }
    
    // 提取内容
    size_t content_pos = str.find("\"content\":");
    if (content_pos != std::string::npos) {
        content_pos += 11;
        size_t quote_end = str.find("\"", content_pos);
        post.content = str.substr(content_pos, quote_end - content_pos);
    }
    
    // 提取作者
    size_t author_pos = str.find("\"author\":");
    if (author_pos != std::string::npos) {
        author_pos += 10;
        size_t quote_end = str.find("\"", author_pos);
        post.author = str.substr(author_pos, quote_end - author_pos);
    }
    
    // 提取创建时间
    size_t created_pos = str.find("\"created_at\":");
    if (created_pos != std::string::npos) {
        created_pos += 14;
        size_t quote_end = str.find("\"", created_pos);
        post.created_at = str.substr(created_pos, quote_end - created_pos);
    }
    
    // 提取更新时间
    size_t updated_pos = str.find("\"updated_at\":");
    if (updated_pos != std::string::npos) {
        updated_pos += 14;
        size_t quote_end = str.find("\"", updated_pos);
        post.updated_at = str.substr(updated_pos, quote_end - updated_pos);
    }
    
    return post;
}

// BlogManager实现
BlogManager::BlogManager(const std::string& data_file) 
    : data_file_(data_file), next_id_(1) {
    loadFromFile();
}

BlogManager::~BlogManager() {
    saveToFile();
}

std::vector<BlogPost> BlogManager::getAllPosts() {
    std::lock_guard<std::mutex> lock(mutex_);
    return posts_;
}

BlogPost BlogManager::getPost(int id) {
    std::lock_guard<std::mutex> lock(mutex_);
    int index = findPostIndex(id);
    if (index >= 0) {
        return posts_[index];
    }
    return BlogPost();
}

int BlogManager::createPost(const BlogPost& post) {
    std::lock_guard<std::mutex> lock(mutex_);
    
    BlogPost new_post = post;
    new_post.id = next_id_++;
    new_post.created_at = generateTimestamp();
    new_post.updated_at = new_post.created_at;
    
    posts_.push_back(new_post);
    saveToFile();
    
    return new_post.id;
}

bool BlogManager::updatePost(int id, const BlogPost& post) {
    std::lock_guard<std::mutex> lock(mutex_);
    
    int index = findPostIndex(id);
    if (index >= 0) {
        posts_[index] = post;
        posts_[index].id = id; // 确保ID不变
        posts_[index].updated_at = generateTimestamp();
        saveToFile();
        return true;
    }
    return false;
}

bool BlogManager::deletePost(int id) {
    std::lock_guard<std::mutex> lock(mutex_);
    
    int index = findPostIndex(id);
    if (index >= 0) {
        posts_.erase(posts_.begin() + index);
        saveToFile();
        return true;
    }
    return false;
}

std::vector<BlogPost> BlogManager::searchPosts(const std::string& keyword) {
    std::lock_guard<std::mutex> lock(mutex_);
    std::vector<BlogPost> results;
    
    std::string lower_keyword = keyword;
    std::transform(lower_keyword.begin(), lower_keyword.end(), lower_keyword.begin(), ::tolower);
    
    for (const auto& post : posts_) {
        std::string lower_title = post.title;
        std::string lower_content = post.content;
        std::transform(lower_title.begin(), lower_title.end(), lower_title.begin(), ::tolower);
        std::transform(lower_content.begin(), lower_content.end(), lower_content.begin(), ::tolower);
        
        if (lower_title.find(lower_keyword) != std::string::npos ||
            lower_content.find(lower_keyword) != std::string::npos) {
            results.push_back(post);
        }
    }
    
    return results;
}

std::vector<BlogPost> BlogManager::getPostsByTag(const std::string& tag) {
    std::lock_guard<std::mutex> lock(mutex_);
    std::vector<BlogPost> results;
    
    for (const auto& post : posts_) {
        for (const auto& post_tag : post.tags) {
            if (post_tag == tag) {
                results.push_back(post);
                break;
            }
        }
    }
    
    return results;
}

bool BlogManager::loadFromFile() {
    std::ifstream file(data_file_);
    if (!file.is_open()) {
        return false;
    }
    
    posts_.clear();
    std::string line;
    std::string current_json;
    bool in_object = false;
    
    while (std::getline(file, line)) {
        current_json += line + "\n";
        
        if (line.find("{") != std::string::npos) in_object = true;
        if (line.find("}") != std::string::npos && in_object) {
            BlogPost post = BlogPost::fromJson(current_json);
            if (post.id > 0) {
                posts_.push_back(post);
                if (post.id >= next_id_) {
                    next_id_ = post.id + 1;
                }
            }
            current_json.clear();
            in_object = false;
        }
    }
    
    file.close();
    return true;
}

bool BlogManager::saveToFile() {
    std::ofstream file(data_file_);
    if (!file.is_open()) {
        return false;
    }
    
    file << "[\n";
    for (size_t i = 0; i < posts_.size(); ++i) {
        if (i > 0) file << ",\n";
        file << posts_[i].toJson();
    }
    file << "\n]";
    
    file.close();
    return true;
}

std::string BlogManager::generateTimestamp() {
    auto now = std::chrono::system_clock::now();
    auto time_t = std::chrono::system_clock::to_time_t(now);
    
    std::ostringstream oss;
    oss << std::put_time(std::localtime(&time_t), "%Y-%m-%d %H:%M:%S");
    return oss.str();
}

int BlogManager::findPostIndex(int id) {
    for (size_t i = 0; i < posts_.size(); ++i) {
        if (posts_[i].id == id) {
            return i;
        }
    }
    return -1;
}