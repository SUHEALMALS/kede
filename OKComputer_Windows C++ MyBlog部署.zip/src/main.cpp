#include <iostream>
#include <string>
#include <thread>
#include <chrono>
#include "../include/server.h"
#include "../include/blog_manager.h"

int main(int argc, char* argv[]) {
    std::cout << "=== C++ Blog System ===" << std::endl;
    std::cout << "Starting server..." << std::endl;
    
    // 初始化博客管理器
    BlogManager blogManager("data/posts.json");
    
    // 创建HTTP服务器
    HttpServer server(8080);
    
    // 设置路由处理器
    server.setBlogManager(&blogManager);
    
    // 启动服务器
    std::cout << "Server starting on http://localhost:8080" << std::endl;
    std::cout << "Press Ctrl+C to stop..." << std::endl;
    
    server.start();
    
    return 0;
}