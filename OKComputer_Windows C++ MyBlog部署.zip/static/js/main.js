// 博客系统主要JavaScript功能

// 全局变量
let currentPage = 1;
let postsPerPage = 6;
let isLoading = false;

// DOM加载完成后初始化
document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
});

// 初始化应用
function initializeApp() {
    // 绑定事件监听器
    bindEventListeners();
    
    // 根据当前页面加载相应内容
    const currentPath = window.location.pathname;
    
    if (currentPath === '/') {
        loadPosts();
    } else if (currentPath.startsWith('/post/')) {
        loadPostContent();
    } else if (currentPath === '/admin') {
        loadAdminData();
    }
}

// 绑定事件监听器
function bindEventListeners() {
    // 滚动加载更多文章
    window.addEventListener('scroll', handleScroll);
    
    // 模态框外部点击关闭
    window.addEventListener('click', function(e) {
        const modal = document.getElementById('postModal');
        if (e.target === modal) {
            closePostModal();
        }
    });
    
    // ESC键关闭模态框
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            closePostModal();
        }
    });
}

// 处理滚动事件
function handleScroll() {
    if (window.location.pathname === '/') {
        const scrollTop = window.pageYOffset;
        const windowHeight = window.innerHeight;
        const documentHeight = document.documentElement.scrollHeight;
        
        // 当滚动到底部附近时加载更多
        if (scrollTop + windowHeight >= documentHeight - 100) {
            if (!isLoading) {
                loadMorePosts();
            }
        }
    }
}

// 加载文章列表
async function loadPosts() {
    try {
        showLoading();
        
        // 模拟API调用
        const response = await simulateApiCall('/api/posts', {
            page: currentPage,
            limit: postsPerPage
        });
        
        if (response.success) {
            renderPosts(response.data.posts);
            updateLoadMoreButton(response.data.hasMore);
        } else {
            showError('加载文章失败');
        }
    } catch (error) {
        console.error('加载文章出错:', error);
        showError('加载文章时发生错误');
    } finally {
        hideLoading();
    }
}

// 渲染文章列表
function renderPosts(posts) {
    const postsGrid = document.getElementById('postsGrid');
    if (!postsGrid) return;
    
    posts.forEach(post => {
        const postElement = createPostElement(post);
        postsGrid.appendChild(postElement);
    });
}

// 创建文章元素
function createPostElement(post) {
    const article = document.createElement('article');
    article.className = 'post-card';
    article.innerHTML = `
        <div class="post-meta">
            <span class="post-date">${formatDate(post.created_at)}</span>
            <div class="post-tags">
                ${post.tags.map(tag => `<span class="tag">${tag}</span>`).join('')}
            </div>
        </div>
        <h4 class="post-title">
            <a href="/post/${post.id}">${post.title}</a>
        </h4>
        <p class="post-excerpt">${post.excerpt || post.content.substring(0, 150)}...</p>
        <div class="post-footer">
            <span class="post-author">作者：${post.author}</span>
            <a href="/post/${post.id}" class="read-more">阅读全文 →</a>
        </div>
    `;
    return article;
}

// 加载更多文章
async function loadMorePosts() {
    if (isLoading) return;
    
    isLoading = true;
    currentPage++;
    
    try {
        const response = await simulateApiCall('/api/posts', {
            page: currentPage,
            limit: postsPerPage
        });
        
        if (response.success) {
            renderPosts(response.data.posts);
            updateLoadMoreButton(response.data.hasMore);
        } else {
            showError('加载更多文章失败');
        }
    } catch (error) {
        console.error('加载更多文章出错:', error);
        showError('加载更多文章时发生错误');
    } finally {
        isLoading = false;
    }
}

// 加载文章详情
async function loadPostContent() {
    const postId = getPostIdFromUrl();
    if (!postId) return;
    
    try {
        const response = await simulateApiCall(`/api/posts/${postId}`);
        
        if (response.success) {
            updatePostContent(response.data);
        } else {
            showError('加载文章失败');
        }
    } catch (error) {
        console.error('加载文章出错:', error);
        showError('加载文章时发生错误');
    }
}

// 更新文章内容
function updatePostContent(post) {
    // 更新页面标题
    document.title = `${post.title} - My Blog`;
    
    // 更新文章标题
    const titleElement = document.querySelector('.post-title');
    if (titleElement) {
        titleElement.textContent = post.title;
    }
    
    // 更新文章元数据
    const dateElement = document.querySelector('.post-date');
    if (dateElement) {
        dateElement.textContent = formatDate(post.created_at);
    }
    
    const authorElement = document.querySelector('.post-author span');
    if (authorElement) {
        authorElement.textContent = `作者：${post.author}`;
    }
    
    // 更新标签
    const tagsElement = document.querySelector('.post-tags');
    if (tagsElement) {
        tagsElement.innerHTML = post.tags.map(tag => `<span class="tag">${tag}</span>`).join('');
    }
    
    // 更新文章内容
    const contentElement = document.querySelector('.post-content');
    if (contentElement) {
        contentElement.innerHTML = post.content;
    }
}

// 加载管理后台数据
async function loadAdminData() {
    try {
        const response = await simulateApiCall('/api/admin/stats');
        
        if (response.success) {
            updateAdminStats(response.data);
        } else {
            showError('加载管理数据失败');
        }
    } catch (error) {
        console.error('加载管理数据出错:', error);
        showError('加载管理数据时发生错误');
    }
}

// 更新管理后台统计数据
function updateAdminStats(stats) {
    // 更新统计卡片
    const statNumbers = document.querySelectorAll('.stat-number');
    if (statNumbers.length >= 4) {
        statNumbers[0].textContent = stats.totalPosts;
        statNumbers[1].textContent = stats.publishedPosts;
        statNumbers[2].textContent = stats.draftPosts;
        statNumbers[3].textContent = stats.visits.toLocaleString();
    }
    
    // 更新文章表格
    renderAdminPosts(stats.posts);
}

// 渲染管理后台文章列表
function renderAdminPosts(posts) {
    const tbody = document.getElementById('postsTableBody');
    if (!tbody) return;
    
    tbody.innerHTML = '';
    
    posts.forEach(post => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${post.id}</td>
            <td>${post.title}</td>
            <td>${post.author}</td>
            <td>${formatDate(post.created_at)}</td>
            <td><span class="status-${post.published ? 'published' : 'draft'}">${post.published ? '已发布' : '草稿'}</span></td>
            <td>
                <button class="btn btn-sm btn-primary" onclick="editPost(${post.id})">编辑</button>
                <button class="btn btn-sm btn-danger" onclick="deletePost(${post.id})">删除</button>
            </td>
        `;
        tbody.appendChild(row);
    });
}

// 显示创建文章模态框
function showCreatePostModal() {
    const modal = document.getElementById('postModal');
    const title = document.getElementById('modalTitle');
    const form = document.getElementById('postForm');
    
    if (modal && title && form) {
        title.textContent = '新建文章';
        form.reset();
        form.dataset.mode = 'create';
        modal.style.display = 'block';
        
        // 聚焦到标题输入框
        document.getElementById('postTitle').focus();
    }
}

// 编辑文章
function editPost(postId) {
    // 根据文章ID获取文章数据
    simulateApiCall(`/api/posts/${postId}`)
        .then(response => {
            if (response.success) {
                showEditPostModal(response.data);
            } else {
                showError('获取文章数据失败');
            }
        })
        .catch(error => {
            console.error('获取文章数据出错:', error);
            showError('获取文章数据时发生错误');
        });
}

// 显示编辑文章模态框
function showEditPostModal(post) {
    const modal = document.getElementById('postModal');
    const title = document.getElementById('modalTitle');
    const form = document.getElementById('postForm');
    
    if (modal && title && form) {
        title.textContent = '编辑文章';
        form.dataset.mode = 'edit';
        form.dataset.postId = post.id;
        
        // 填充表单数据
        document.getElementById('postTitle').value = post.title;
        document.getElementById('postAuthor').value = post.author;
        document.getElementById('postTags').value = post.tags.join(', ');
        document.getElementById('postContent').value = post.content;
        document.getElementById('postPublished').checked = post.published;
        
        modal.style.display = 'block';
        
        // 聚焦到标题输入框
        document.getElementById('postTitle').focus();
    }
}

// 关闭文章模态框
function closePostModal() {
    const modal = document.getElementById('postModal');
    if (modal) {
        modal.style.display = 'none';
    }
}

// 保存文章
async function savePost() {
    const form = document.getElementById('postForm');
    if (!form) return;
    
    const formData = new FormData(form);
    const postData = {
        title: formData.get('title'),
        author: formData.get('author'),
        tags: formData.get('tags').split(',').map(tag => tag.trim()).filter(tag => tag),
        content: formData.get('content'),
        published: formData.has('published')
    };
    
    // 验证必填字段
    if (!postData.title || !postData.author || !postData.content) {
        showError('请填写所有必填字段');
        return;
    }
    
    try {
        const mode = form.dataset.mode;
        let endpoint, method;
        
        if (mode === 'edit') {
            const postId = form.dataset.postId;
            endpoint = `/api/posts/${postId}`;
            method = 'PUT';
        } else {
            endpoint = '/api/posts';
            method = 'POST';
        }
        
        const response = await simulateApiCall(endpoint, postData, method);
        
        if (response.success) {
            showSuccess(mode === 'edit' ? '文章更新成功' : '文章创建成功');
            closePostModal();
            
            // 重新加载当前页面数据
            if (window.location.pathname === '/admin') {
                loadAdminData();
            } else {
                loadPosts();
            }
        } else {
            showError(mode === 'edit' ? '文章更新失败' : '文章创建失败');
        }
    } catch (error) {
        console.error('保存文章出错:', error);
        showError('保存文章时发生错误');
    }
}

// 删除文章
function deletePost(postId) {
    if (!confirm('确定要删除这篇文章吗？此操作不可撤销。')) {
        return;
    }
    
    simulateApiCall(`/api/posts/${postId}`, {}, 'DELETE')
        .then(response => {
            if (response.success) {
                showSuccess('文章删除成功');
                
                // 重新加载当前页面数据
                if (window.location.pathname === '/admin') {
                    loadAdminData();
                } else {
                    loadPosts();
                }
            } else {
                showError('文章删除失败');
            }
        })
        .catch(error => {
            console.error('删除文章出错:', error);
            showError('删除文章时发生错误');
        });
}

// 分享功能
function shareToWeibo() {
    const title = document.querySelector('.post-title')?.textContent || document.title;
    const url = window.location.href;
    window.open(`https://service.weibo.com/share/share.php?url=${encodeURIComponent(url)}&title=${encodeURIComponent(title)}`);
}

function shareToWeChat() {
    alert('请使用微信扫描二维码分享');
}

function copyLink() {
    navigator.clipboard.writeText(window.location.href).then(() => {
        showSuccess('链接已复制到剪贴板');
    }).catch(() => {
        showError('复制链接失败');
    });
}

// 工具函数
function getPostIdFromUrl() {
    const path = window.location.pathname;
    const match = path.match(/\/post\/(\d+)/);
    return match ? parseInt(match[1]) : null;
}

function formatDate(timestamp) {
    const date = new Date(timestamp);
    return date.toISOString().split('T')[0];
}

function showLoading() {
    // 显示加载指示器
    const loadingElement = document.getElementById('loadingIndicator');
    if (loadingElement) {
        loadingElement.style.display = 'block';
    }
}

function hideLoading() {
    // 隐藏加载指示器
    const loadingElement = document.getElementById('loadingIndicator');
    if (loadingElement) {
        loadingElement.style.display = 'none';
    }
}

function showError(message) {
    // 显示错误消息
    showNotification(message, 'error');
}

function showSuccess(message) {
    // 显示成功消息
    showNotification(message, 'success');
}

function showNotification(message, type = 'info') {
    // 创建通知元素
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.textContent = message;
    
    // 添加样式
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 1rem 1.5rem;
        border-radius: 0.5rem;
        color: white;
        font-weight: 500;
        z-index: 10000;
        animation: slideIn 0.3s ease;
        max-width: 300px;
        word-wrap: break-word;
    `;
    
    // 根据类型设置背景色
    switch (type) {
        case 'error':
            notification.style.backgroundColor = '#dc2626';
            break;
        case 'success':
            notification.style.backgroundColor = '#10b981';
            break;
        case 'warning':
            notification.style.backgroundColor = '#f59e0b';
            break;
        default:
            notification.style.backgroundColor = '#2563eb';
    }
    
    // 添加到页面
    document.body.appendChild(notification);
    
    // 3秒后自动移除
    setTimeout(() => {
        notification.style.animation = 'slideOut 0.3s ease';
        setTimeout(() => {
            if (notification.parentNode) {
                notification.parentNode.removeChild(notification);
            }
        }, 300);
    }, 3000);
}

// 模拟API调用
function simulateApiCall(endpoint, data = null, method = 'GET') {
    return new Promise((resolve) => {
        // 模拟网络延迟
        setTimeout(() => {
            // 根据端点返回模拟数据
            switch (endpoint) {
                case '/api/posts':
                    resolve({
                        success: true,
                        data: {
                            posts: generateMockPosts(data?.page || 1, data?.limit || 6),
                            hasMore: data?.page < 3
                        }
                    });
                    break;
                    
                case '/api/posts/1':
                case '/api/posts/2':
                case '/api/posts/3':
                    resolve({
                        success: true,
                        data: generateMockPost(parseInt(endpoint.split('/').pop()))
                    });
                    break;
                    
                case '/api/admin/stats':
                    resolve({
                        success: true,
                        data: {
                            totalPosts: 3,
                            publishedPosts: 2,
                            draftPosts: 1,
                            visits: 1234,
                            posts: [
                                { id: 1, title: '构建高性能C++博客系统', author: 'Developer', created_at: '2024-12-04', published: true },
                                { id: 2, title: '现代前端开发最佳实践', author: 'Developer', created_at: '2024-12-03', published: true },
                                { id: 3, title: '算法优化与性能分析', author: 'Developer', created_at: '2024-12-02', published: false }
                            ]
                        }
                    });
                    break;
                    
                default:
                    if (method === 'POST' || method === 'PUT') {
                        resolve({ success: true, data: { id: Date.now() } });
                    } else if (method === 'DELETE') {
                        resolve({ success: true });
                    } else {
                        resolve({ success: false, message: 'Endpoint not found' });
                    }
            }
        }, 500); // 500ms延迟模拟网络请求
    });
}

// 生成模拟文章数据
function generateMockPosts(page, limit) {
    const posts = [
        {
            id: 1,
            title: '构建高性能C++博客系统',
            author: 'Developer',
            created_at: '2024-12-04T10:00:00Z',
            tags: ['C++', 'Web开发'],
            excerpt: '探索如何使用现代C++技术栈构建一个高性能的博客系统，包括HTTP服务器、数据持久化和前端界面设计...',
            content: generateMockPostContent('构建高性能C++博客系统')
        },
        {
            id: 2,
            title: '现代前端开发最佳实践',
            author: 'Developer',
            created_at: '2024-12-03T10:00:00Z',
            tags: ['JavaScript', '前端'],
            excerpt: '分享现代前端开发中的最佳实践，包括组件化开发、状态管理、性能优化等关键技术点...',
            content: generateMockPostContent('现代前端开发最佳实践')
        },
        {
            id: 3,
            title: '算法优化与性能分析',
            author: 'Developer',
            created_at: '2024-12-02T10:00:00Z',
            tags: ['算法', '数据结构'],
            excerpt: '深入探讨常见算法的优化技巧，如何通过算法改进提升程序性能，以及性能分析的方法和工具...',
            content: generateMockPostContent('算法优化与性能分析')
        }
    ];
    
    // 根据分页返回数据
    const startIndex = (page - 1) * limit;
    return posts.slice(startIndex, startIndex + limit);
}

// 生成模拟单篇文章数据
function generateMockPost(id) {
    const posts = generateMockPosts(1, 3);
    return posts.find(post => post.id === id) || posts[0];
}

// 生成模拟文章内容
function generateMockPostContent(title) {
    return `
        <p>在这篇文章中，我将详细介绍${title}的相关内容。这是一个深入的技术话题，需要我们仔细探讨。</p>
        
        <h2>背景介绍</h2>
        <p>随着技术的不断发展，${title}变得越来越重要。我们需要理解其核心概念和实现原理。</p>
        
        <h2>核心概念</h2>
        <p>首先，让我们了解一些基本概念：</p>
        <ul>
            <li>概念一：这是第一个重要的概念</li>
            <li>概念二：这是第二个重要的概念</li>
            <li>概念三：这是第三个重要的概念</li>
        </ul>
        
        <h2>实现方法</h2>
        <p>接下来，我们将探讨具体的实现方法。这里会涉及一些代码示例和最佳实践。</p>
        
        <h2>总结</h2>
        <p>通过本文的学习，我们深入了解了${title}的各个方面。希望这些内容对您有所帮助。</p>
    `;
}

// 添加CSS动画样式
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from {
            transform: translateX(100%);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
    
    @keyframes slideOut {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(100%);
            opacity: 0;
        }
    }
`;
document.head.appendChild(style);